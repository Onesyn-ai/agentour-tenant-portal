# @agentour/sdk

Headless TypeScript client for Agentour sessions, the channel-neutral
`agentour.experience/1.0` document, interactions, approvals, usage, artifacts and
resumable SSE. It renders nothing and exposes only data authorized for the
identified Agentour account (or by OAuth scopes when OAuth is used).

```ts
import { AgentourClient } from "@agentour/sdk";

const client = new AgentourClient({ baseUrl: "https://agentour.ai", token: "ak_..." });
const session = await client.createSession("action-planner-agent");
await client.send(session.session_id, "为明天的面试制定计划");

const presentation = await client.presentation(session.session_id, {
  forms: true,
  partial_updates: true,
});
console.log(presentation.experience.blocks);
```

High-level, framework-independent usage:

```ts
const run = await client.run({
  agentId: "action-planner-agent",
  input: "为明天的面试制定计划",
});

const unsubscribe = run.subscribe(state => {
  renderWithAnyFrameworkOrPlainDOM(state);
});

await run.send("补充：目标岗位是产品运营");
// unsubscribe(); run.dispose();
```

The Experience document is the same semantic contract consumed by Agentour Web
and channel adapters. Renderers may choose native controls, but must preserve
state, fields, actions, permissions, revisions and artifact delivery facts.
