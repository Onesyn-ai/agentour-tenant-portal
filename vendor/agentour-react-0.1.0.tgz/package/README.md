# @agentour/sdk-react

Default React components for the Agentour Presentation and
`agentour.experience/1.0` contracts.

```tsx
import { ExperienceRenderer } from "@agentour/sdk-react";

<ExperienceRenderer
  experience={presentation.experience}
  onAction={action => executeAction(action)}
  onSubmit={(block, values) => submitInteraction(block.id, values)}
/>
```

The renderer includes status, metrics, markdown/text, collapsible sections,
tables and forms. Form fields support text, textarea, number, checkbox, select,
multi-select, person fallback, date, time, datetime and file input. Applications
can replace any visual component while retaining the same semantic document.
